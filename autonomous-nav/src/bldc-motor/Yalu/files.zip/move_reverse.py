import Jetson.GPIO as GPIO
import time

# ── Pin assignments ──────────────────────────────────────────────────────────
# Yalu S6-23 wiring:
#   PIN 33  → RC filter (1kΩ + 10µF to GND) → Throttle red wire
#   PIN 7   → Reverse connector  (LOW = forward, HIGH = reverse)
#   PIN 40  → Power lock wire    (HIGH = controller on)
#   PIN 39  → GND (shared with throttle black wire)
# ─────────────────────────────────────────────────────────────────────────────

PWM_PIN     = 33
REVERSE_PIN = 7
EN_PIN      = 40
PWM_FREQ    = 1000   # Hz

GPIO.setmode(GPIO.BOARD)
GPIO.setup(PWM_PIN,     GPIO.OUT)
GPIO.setup(REVERSE_PIN, GPIO.OUT)
GPIO.setup(EN_PIN,      GPIO.OUT)

# ── Safe initial state ───────────────────────────────────────────────────────
GPIO.output(EN_PIN,      GPIO.LOW)   # Controller off
GPIO.output(REVERSE_PIN, GPIO.LOW)   # Start in forward — set reverse AFTER enabling

pwm = GPIO.PWM(PWM_PIN, PWM_FREQ)
pwm.start(0)

try:
    time.sleep(0.3)

    GPIO.output(EN_PIN, GPIO.HIGH)   # Power lock ON
    time.sleep(0.5)                  # Wait for Yalu initialisation

    # ── Engage reverse ───────────────────────────────────────────────────────
    # Yalu Reverse connector: momentary HIGH pulse (~200 ms) toggles direction.
    # Pull HIGH, hold, then leave HIGH to keep reverse engaged.
    # NOTE: some Yalu variants latch on rising edge — test with a short pulse first.
    GPIO.output(REVERSE_PIN, GPIO.HIGH)
    time.sleep(0.2)                  # Hold the toggle pulse

    # ── Ramp up ──────────────────────────────────────────────────────────────
    for dc in range(10, 101, 5):
        pwm.ChangeDutyCycle(dc)
        time.sleep(0.05)

    print("REVERSE running")
    time.sleep(5)

    # ── Ramp down ────────────────────────────────────────────────────────────
    for dc in range(100, 9, -5):
        pwm.ChangeDutyCycle(dc)
        time.sleep(0.05)

    pwm.ChangeDutyCycle(0)
    time.sleep(0.2)

except KeyboardInterrupt:
    pass

finally:
    try:
        pwm.ChangeDutyCycle(0)
    except Exception:
        pass
    try:
        pwm.stop()
    except Exception:
        pass
    try:
        GPIO.output(EN_PIN,      GPIO.LOW)
        GPIO.output(REVERSE_PIN, GPIO.LOW)  # Reset direction to forward
    except Exception:
        pass
    try:
        GPIO.cleanup()
    except OSError:
        pass
    print("REVERSE done")
