import Jetson.GPIO as GPIO
import time

# ── Pin assignments ──────────────────────────────────────────────────────────
# Yalu S6-23 wiring:
#   PIN 33  → RC filter (1kΩ + 10µF to GND) → Throttle red wire
#   PIN 7   → Reverse connector  (LOW = forward, HIGH = reverse)
#   PIN 40  → Power lock wire    (HIGH = controller on)
#   PIN 39  → GND (shared with throttle black wire)
#
# PIN 32 (SIG) is no longer needed — leave it disconnected.
# ─────────────────────────────────────────────────────────────────────────────

PWM_PIN     = 33   # Speed: PWM → RC filter → Throttle input
REVERSE_PIN = 7    # Direction: LOW = forward, HIGH = reverse
EN_PIN      = 40   # Enable: HIGH = power on

# Yalu throttle expects 0–4 V analog; Jetson GPIO PWM runs at 3.3 V logic.
# RC low-pass filter converts PWM duty cycle to ~0–3.3 V DC.
# Use 1 kHz PWM frequency to keep ripple low through the RC filter.
PWM_FREQ = 1000    # Hz

GPIO.setmode(GPIO.BOARD)
GPIO.setup(PWM_PIN,     GPIO.OUT)
GPIO.setup(REVERSE_PIN, GPIO.OUT)
GPIO.setup(EN_PIN,      GPIO.OUT)

# ── Safe initial state ───────────────────────────────────────────────────────
GPIO.output(EN_PIN,      GPIO.LOW)   # Controller off
GPIO.output(REVERSE_PIN, GPIO.LOW)   # FORWARD direction locked

pwm = GPIO.PWM(PWM_PIN, PWM_FREQ)
pwm.start(0)                         # 0 % duty = 0 V at throttle

try:
    time.sleep(0.3)                  # Let REVERSE_PIN latch before enabling

    GPIO.output(EN_PIN, GPIO.HIGH)   # Power lock ON — controller wakes up
    time.sleep(0.5)                  # Yalu needs ~400 ms to initialise after power-on

    # ── Ramp up ──────────────────────────────────────────────────────────────
    # Yalu throttle deadband: signal below ~8 % duty cycle (~0.26 V) is ignored.
    # Start ramp from 10 % to clear the deadband cleanly.
    for dc in range(10, 101, 5):
        pwm.ChangeDutyCycle(dc)
        time.sleep(0.05)             # Slower ramp than JYQD — Yalu is current-limited

    print("FORWARD running")
    time.sleep(5)                    # Constant-speed run — adjust as needed

    # ── Ramp down ────────────────────────────────────────────────────────────
    for dc in range(100, 9, -5):
        pwm.ChangeDutyCycle(dc)
        time.sleep(0.05)

    pwm.ChangeDutyCycle(0)           # Drop to 0 V before disabling
    time.sleep(0.2)

except KeyboardInterrupt:
    pass

finally:
    try:
        pwm.ChangeDutyCycle(0)
    except Exception:
        pass
    try:
        pwm.stop()
    except Exception:
        pass
    try:
        GPIO.output(EN_PIN, GPIO.LOW)       # Power lock OFF
        GPIO.output(REVERSE_PIN, GPIO.LOW)  # Leave in forward state
    except Exception:
        pass
    try:
        GPIO.cleanup()
    except OSError:
        pass                                # Known Jetson.GPIO 2.1.x fd-close bug
    print("FORWARD done")
