import subprocess
import sys
import time

FORWARD_SCRIPT = "move_forward.py"
REVERSE_SCRIPT = "move_reverse.py"

# ── Notes on Yalu direction switching ────────────────────────────────────────
# The Yalu S6-23 Reverse connector toggles direction state inside the controller.
# You MUST NOT switch direction while the motor is spinning — this can damage
# the FETs. The ramp-down in each script brings speed to 0 before exiting,
# but we add an extra dead-time pause here between scripts for safety.
# ─────────────────────────────────────────────────────────────────────────────

DIRECTION_CHANGE_PAUSE = 2.0   # seconds — DO NOT reduce below 1.0

def run_motor(script):
    print(f"Launching: {script}")
    result = subprocess.run(
        [sys.executable, script],
        timeout=30
    )
    if result.returncode != 0:
        print(f"WARNING: {script} exited with code {result.returncode}")
    print(f"Waiting {DIRECTION_CHANGE_PAUSE}s before direction change...")
    time.sleep(DIRECTION_CHANGE_PAUSE)

try:
    while True:
        run_motor(FORWARD_SCRIPT)
        run_motor(REVERSE_SCRIPT)

except KeyboardInterrupt:
    print("Controller stopped")
